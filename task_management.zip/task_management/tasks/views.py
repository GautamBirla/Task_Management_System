from django.shortcuts import render, redirect
from .models import Task
from .forms import TaskForm
from django.utils import timezone

def home(request):
    tasks = Task.objects.filter(deleted=False)
    return render(request, 'home.html', {'tasks': tasks})

def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = TaskForm()
    return render(request, 'create_task.html', {'form': form})

def edit_task(request, pk):
    task = Task.objects.get(pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = TaskForm(instance=task)
    return render(request, 'edit_task.html', {'form': form, 'task': task})

def delete_task(request, pk):
    task = Task.objects.get(pk=pk)
    task.deleted = True
    task.save()
    return redirect('home')

def complete_task(request, pk):
    task = Task.objects.get(pk=pk)
    task.status = 'Completed'
    task.completed_at = timezone.now()
    task.save()
    return redirect('home')

def completed_tasks(request):
    tasks = Task.objects.filter(status='Completed', deleted=False)
    return render(request, 'completed_tasks.html', {'tasks': tasks})

def deleted_tasks(request):
    tasks = Task.objects.filter(deleted=True)
    return render(request, 'deleted_tasks.html', {'tasks': tasks})

def permanent_delete_task(request, pk):
    task = Task.objects.get(pk=pk)
    task.delete()
    return redirect('deleted_tasks')
