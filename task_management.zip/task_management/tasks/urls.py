from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_task, name='create_task'),
    path('edit/<int:pk>/', views.edit_task, name='edit_task'),
    path('delete/<int:pk>/', views.delete_task, name='delete_task'),
    path('complete/<int:pk>/', views.complete_task, name='complete_task'),
    path('completed/', views.completed_tasks, name='completed_tasks'),
    path('deleted/', views.deleted_tasks, name='deleted_tasks'),
    path('permanent_delete/<int:pk>/', views.permanent_delete_task, name='permanent_delete_task'),

]
